const mysql = require('mysql');

module.exports = class {
  constructor() {

  }

  async connect() {
    const connection = mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'wuzimu'
    });

      connection.connect(function(err) {
        if(err == null) {
          console.log(`Banco de dados conectado, nenhum erro encontrado.`);
        }else {
          console.log(`Banco de dados conectado, Erros: ${err}`);
        }
      });
  
    this.connection = connection
  }

  close() {
    this.connection.end(function() {
      console.log(`Banco de dados desconectado`);
    });
  }
}