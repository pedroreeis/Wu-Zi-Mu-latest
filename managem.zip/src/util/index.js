module.exports = {
  mstohours: require('./others/mstohours'),
  canvas: require('./canvas/canvas'),
  attach: require('./canvas/attachmentBuilder')
};